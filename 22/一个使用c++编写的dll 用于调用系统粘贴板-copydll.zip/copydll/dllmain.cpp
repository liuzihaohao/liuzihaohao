#include <string>
#include <windows.h>
#define DLLEXPORT extern "C" __declspec(dllexport)
using namespace std;
DLLEXPORT void setClip(char* abcddd) 
{
	string s=abcddd;
    OpenClipboard(0);
    EmptyClipboard();
    HGLOBAL hg = GlobalAlloc(GMEM_MOVEABLE, s.size()+1);
    if (!hg) {
        CloseClipboard();
        return;
    }
    memcpy(GlobalLock(hg), s.c_str(), s.size()+1);
    GlobalUnlock(hg);
    SetClipboardData(CF_TEXT, hg);
    CloseClipboard();
    GlobalFree(hg);
}
