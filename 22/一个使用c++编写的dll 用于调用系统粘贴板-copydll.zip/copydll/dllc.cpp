#include <iostream>
#include <string>
#include <windows.h>
using namespace std;
typedef void(*ptrSub)(char*);
HMODULE dllmod = LoadLibrary("add.dll");
int main(){
    if (dllmod != NULL){
        ptrSub setClip = (ptrSub)GetProcAddress(dllmod, "setClip");
        if (setClip != NULL)
        {
           setClip("casdfdf");
        }
        FreeLibrary(dllmod);
    }
}
